# Editor internals only.
